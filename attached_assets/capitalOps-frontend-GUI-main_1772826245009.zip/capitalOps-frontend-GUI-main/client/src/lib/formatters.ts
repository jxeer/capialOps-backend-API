export function formatCurrency(value: number): string {
  if (value >= 1000000) {
    return `$${(value / 1000000).toFixed(1)}M`;
  }
  if (value >= 1000) {
    return `$${(value / 1000).toFixed(0)}K`;
  }
  return `$${value.toLocaleString()}`;
}

export function formatFullCurrency(value: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(value);
}

export function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat("en-US").format(value);
}

export function getStatusColor(status: string): string {
  const map: Record<string, string> = {
    Active: "bg-chart-2/15 text-chart-2",
    "In Progress": "bg-chart-1/15 text-chart-1",
    Completed: "bg-chart-2/15 text-chart-2",
    Planning: "bg-chart-3/15 text-chart-3",
    "On Hold": "bg-muted text-muted-foreground",
    "Pre-dev": "bg-chart-4/15 text-chart-4",
    Stabilized: "bg-chart-2/15 text-chart-2",
    Draft: "bg-muted text-muted-foreground",
    Funded: "bg-chart-2/15 text-chart-2",
    Closed: "bg-muted text-muted-foreground",
    Pending: "bg-chart-3/15 text-chart-3",
    "Soft Commit": "bg-chart-1/15 text-chart-1",
    "Hard Commit": "bg-chart-4/15 text-chart-4",
    Withdrawn: "bg-destructive/15 text-destructive",
    Delayed: "bg-destructive/15 text-destructive",
    Open: "bg-chart-3/15 text-chart-3",
    Mitigated: "bg-chart-1/15 text-chart-1",
    Resolved: "bg-chart-2/15 text-chart-2",
    Current: "bg-chart-2/15 text-chart-2",
    Expired: "bg-destructive/15 text-destructive",
    Low: "bg-chart-2/15 text-chart-2",
    Medium: "bg-chart-3/15 text-chart-3",
    High: "bg-chart-5/15 text-chart-5",
    Urgent: "bg-destructive/15 text-destructive",
    Critical: "bg-destructive/15 text-destructive",
    Cancelled: "bg-muted text-muted-foreground",
  };
  return map[status] || "bg-muted text-muted-foreground";
}

export function getRiskColor(level: string): string {
  const map: Record<string, string> = {
    Low: "text-chart-2",
    Medium: "text-chart-3",
    High: "text-chart-5",
    Critical: "text-destructive",
  };
  return map[level] || "text-muted-foreground";
}
